-- The playable window: draws the world from Combat.lua / Zone.lua with WoW's own art and takes the mouse and keys.
--   Left click   walk; click a monster to attack it with your wand (free, no mana)
--   Right click  cast the selected skill at the cursor      Shift + left click  cast without moving
--   1-8          select a skill slot                         Tab / mouse wheel   rotate to the next slot
--   K            skill tree: hover a skill and press 1-8 to put it on that slot
-- Drag the window by its title bar. The rules all live in Combat.lua / Tree.lua; this file draws and listens.
local ADDON, ns = ...
local Combat, Tree, Skills, Zone = ns.Combat, ns.Tree, ns.Skills, ns.Zone

local Game = {}
ns.Game = Game

local VW, VH = 640, 400            -- the viewport, in the same units Combat.lua uses
local HUD_H, TITLE_H = 104, 24
local MAX_MON, MAX_DOODAD, MAX_PROJ, MAX_BLAST, MAX_FLOAT, MAX_DROP = 14, 22, 16, 6, 20, 8
local SLOTS = 8
local ATTACK_RANGE = 300           -- how close you get to a clicked monster before the wand starts firing
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

-- Animation ids (AnimationData). 0 stand, 1 death, 4 walk, 5 run, 16 unarmed attack are standard; the cast id is a
-- guess to be corrected with /dread animtest.
Game.ANIM = { STAND = 0, DEATH = 1, WALK = 4, RUN = 5, ATTACK = 16, CAST = 51 }

-- Spell icons: guesses from memory of WoW's icon names.
local ICONS = {
  scorch="Spell_Fire_SoulBurn", evocation="Spell_Nature_Purge", dragons_breath="Spell_Fire_Incinerate",
  blazing_speed="Spell_Fire_BurningSpeed", fireball="Spell_Fire_FlameBolt", flamestrike="Spell_Fire_SelfDestruct",
  combustion="Spell_Fire_SealOfFire", meteor="Spell_Fire_Meteorstorm", master_of_flame="Spell_Fire_FlameShock",
  flame_spirit="Spell_Fire_Elemental_Totem",
  frostbolt="Spell_Frost_FrostBolt02", ice_barrier="Spell_Ice_Lament", frost_nova="Spell_Frost_FrostNova",
  ice_lance="Spell_Frost_FrostBolt", frost_armor="Spell_Frost_FrostArmor02", glacial_spike="Spell_Frost_Glacier",
  blizzard="Spell_Frost_IceStorm", icicle_cloak="Spell_Frost_ChillingArmor", frozen_orb="Spell_Frost_FrozenCore",
  piercing_cold="Spell_Frost_ChillingBlast",
  arcing_bolts="Spell_Nature_Lightning", static_shock="Spell_Nature_LightningShield", force_pull="Spell_Nature_WispSplode",
  thunder_nova="Spell_Nature_ThunderClap", lightning_bolt="Spell_Nature_Lightning", chain_lightning="Spell_Nature_ChainLightning",
  blink="Spell_Arcane_Blink", storm_cloud="Spell_Nature_CallStorm", mana_shield="Spell_Shadow_DetectLesserInvisibility",
  conductor="Spell_Nature_StormReach", wand="INV_Wand_07",
}
local function icon_path(id) return "Interface\\Icons\\" .. (ICONS[id] or "INV_Misc_QuestionMark") end

local COLORS = { fire = { 1, 0.45, 0.1 }, cold = { 0.45, 0.75, 1 }, lightning = { 0.75, 0.6, 1 }, physical = { 0.9, 0.9, 0.9 } }
local function element_of(id) if id == "wand" then return "physical" end return Skills.byId[id].element end

-- Spell-effect models by fileDataID (from the community listfile; modern clients want ids, not paths).
local PROJ_MODEL = { scorch = 166129, fireball = 166129, frostbolt = 166214, ice_lance = 166214, glacial_spike = 166214,
                     arcing_bolts = 166497, lightning_bolt = 166497 }
local PROJ_SCALE = { scorch = 0.6, ice_lance = 0.7, arcing_bolts = 0.5, glacial_spike = 1.3 }
local BLAST_MODEL = { fire = 166114, cold = 166210, lightning = 166496 }

local world, area, cam = nil, nil, { x = 0, y = 0 }
local bar, sel = {}, 1
local target, hover_id
local toast_t = 0
local frame, arena, hud, tree_frame, handle
local ground, ground2
local mon_f, doodad_f, proj_f, blast_f, float_f, drop_f = {}, {}, {}, {}, {}, {}
local doodad_slot = {}                -- scenery piece -> its frame, so models are not reassigned as you walk
local player_model
local life_orb, mana_orb, xp_bar, info_text, hint_text, over_text, zone_text, toast_text, exit_marks
local reset_btn, reset_armed
local solid_f, solid_on, solid_sizes = {}, false, {}
local slots = {}
Game.tree_buttons = {}
Game.paused = false

local function say(msg) print("|cffff5555Dread|r " .. msg) end

---------------------------------------------------------------- the save
local function save()
  if not world then return end
  DreadDB = DreadDB or {}
  DreadDB.char = Combat.snapshot(world)
  local b = {}
  for i = 1, SLOTS do b[i] = bar[i] or false end
  DreadDB.bar = b
end

local function castable(id) return Combat.SHAPES[id] ~= nil and id ~= "wand" end

local function learned_spells()
  local list = {}
  for _, sk in ipairs(Skills) do
    if Tree.points_in(world.player.st, sk.id) > 0 and castable(sk.id) then list[#list + 1] = sk.id end
  end
  return list
end

-- New spells go into the first empty slot; spells you no longer have leave the bar.
local function sync_bar()
  local changed = false
  local have = {}
  for i = 1, SLOTS do
    local id = bar[i]
    if id and Tree.points_in(world.player.st, id) < 1 then bar[i], changed = nil, true end
    if bar[i] then have[bar[i]] = true end
  end
  for _, id in ipairs(learned_spells()) do
    if not have[id] then
      for i = 1, SLOTS do if not bar[i] then bar[i], have[id], changed = id, true, true; break end end
    end
  end
  if not bar[sel] then
    for i = 1, SLOTS do if bar[i] then sel = i; break end end
  end
  if changed then save() end
end

local function rotate(dir)
  for step = 1, SLOTS do
    local i = ((sel - 1 + dir * step) % SLOTS) + 1
    if bar[i] then sel = i; return end
  end
end

---------------------------------------------------------------- worlds and areas
local function enter(name, arrive)
  area = Zone.get(name)
  Combat.enter(world, area)
  if arrive then world.player.x, world.player.y = arrive.x, arrive.y end
  target = nil
  doodad_slot = {}
  for _, f in ipairs(doodad_f) do f:Hide(); f.owner = nil end      -- free every scenery frame for the new area
  local fl = area.floor
  ground:SetTexture(fl.base, "REPEAT", "REPEAT")
  ground:SetVertexColor(fl.tint[1], fl.tint[2], fl.tint[3])
  ground2:SetTexture(fl.overlay, "REPEAT", "REPEAT")
  ground2:SetVertexColor(fl.overlay_tint[1], fl.overlay_tint[2], fl.overlay_tint[3])
  ground2:SetAlpha(fl.overlay_alpha)
  toast_text:SetText(area.title); toast_t = 3
end

local function new_world()
  local seed = (time and time() or 1) % 2147483647
  world = Combat.new({ w = 2400, h = 1500, seed = seed })
  if DreadDB and DreadDB.char then Combat.restore(world, DreadDB.char) end
  bar = {}
  if DreadDB and type(DreadDB.bar) == "table" then
    for i = 1, SLOTS do local id = DreadDB.bar[i]; if type(id) == "string" and Skills.byId[id] then bar[i] = id end end
  end
  sel = 1
  hover_id = nil
  if frame then enter(Zone.START) end
  sync_bar()
end

---------------------------------------------------------------- small helpers
local function tex(parent, layer) return parent:CreateTexture(nil, layer or "ARTWORK") end
local function fstr(parent, size) return parent:CreateFontString(nil, "OVERLAY", size or "GameFontNormal") end
local function try(fn, ...) return pcall(fn, ...) end

local function world_xy()                 -- the cursor, in world coordinates
  local cx, cy = GetCursorPosition()
  local s = frame:GetEffectiveScale()
  return cx / s - arena:GetLeft() + cam.x, cy / s - arena:GetBottom() + cam.y
end

local function place(f, wx, wy, h)       -- feet of a model at a world position
  f:ClearAllPoints()
  f:SetPoint("BOTTOM", arena, "BOTTOMLEFT", wx - cam.x, wy - cam.y - h * 0.15)
end

local function depth(f, wy) f:SetFrameLevel(arena:GetFrameLevel() + 3 + math.floor((area.h - wy) / 6)) end

local function set_anim(f, id)
  if f.anim ~= id then try(f.SetAnimation, f, id); f.anim = id end
end

local function face(f, dx, dy)
  if dx ~= 0 or dy ~= 0 then try(f.SetFacing, f, atan2(dy, dx) + (DreadDB and DreadDB.facing or 0)) end
end

---------------------------------------------------------------- the tree window
local function tooltip(btn, id)
  local sk = Skills.byId[id]
  local st = world.player.st
  GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
  GameTooltip:AddLine(sk.name, 1, 0.82, 0)
  GameTooltip:AddLine("Level " .. sk.req .. "  |  " .. sk.tree, 0.7, 0.7, 0.7)
  local pts = Tree.points_in(st, id)
  GameTooltip:AddLine("Points: " .. pts .. " / " .. Skills.MAX_POINTS, 1, 1, 1)
  if #sk.prereqs > 0 then
    local names = {}
    for _, p in ipairs(sk.prereqs) do names[#names + 1] = Skills.byId[p].name end
    GameTooltip:AddLine("Needs: " .. table.concat(names, ", "), 0.9, 0.6, 0.6)
  end
  if castable(id) then
    GameTooltip:AddLine("Hover and press 1-8 to put it on that slot of your bar", 0.5, 1, 0.5)
  elseif sk.kind ~= "passive" and sk.kind ~= "mastery" then
    GameTooltip:AddLine("Not castable yet in this build", 1, 0.3, 0.3)
  end
  if sk.dmg then
    local lo, hi = Tree.damage(st, id)
    if lo then GameTooltip:AddLine(string.format("Damage now: %d - %d", math.floor(lo), math.floor(hi)), 0.6, 1, 0.6) end
    local s2 = { points = {}, level = 99, quest_points = 0 }
    for k, v in pairs(st.points) do s2.points[k] = v end
    s2.points[id] = math.min(Skills.MAX_POINTS, pts + 1)
    local lo2, hi2 = Tree.damage(s2, id)
    if lo2 then GameTooltip:AddLine(string.format("Next point: %d - %d", math.floor(lo2), math.floor(hi2)), 0.6, 0.8, 1) end
  end
  if sk.mana and pts > 0 then GameTooltip:AddLine(string.format("Mana: %.1f", Tree.mana_cost(st, id)), 0.5, 0.7, 1) end
  if sk.effect and pts > 0 then
    GameTooltip:AddLine(string.format("%s: %g", sk.effect.type, sk.effect.base + sk.effect.per_level * (pts - 1)), 0.8, 0.8, 0.8)
  end
  for _, s in ipairs(sk.syn or {}) do
    GameTooltip:AddLine(string.format("+%d%% per point in %s (you have %d)", s.pct, Skills.byId[s.from].name, Tree.points_in(st, s.from)), 0.9, 0.8, 0.4)
  end
  GameTooltip:Show()
end

local function refresh_tree()
  if not tree_frame then return end
  local st = world.player.st
  tree_frame.title:SetText(string.format("Skills   points to spend: %d", Tree.points_free(st)))
  for id, b in pairs(Game.tree_buttons) do
    local pts = Tree.points_in(st, id)
    local ok = Tree.can_allocate(st, id)
    b.count:SetText(pts > 0 and tostring(pts) or "")
    b.icon:SetDesaturated(pts == 0 and not ok)
    b.icon:SetAlpha((pts > 0 or ok) and 1 or 0.45)
  end
end

local function build_tree()
  tree_frame = CreateFrame("Frame", "DreadTreeFrame", UIParent, "BackdropTemplate")
  tree_frame:SetSize(3 * 4 * 50 + 40, 6 * 56 + 70)
  tree_frame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 8, 0)
  tree_frame:SetClampedToScreen(true)
  tree_frame:SetFrameStrata("DIALOG")
  tree_frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
  tree_frame:SetBackdropColor(0, 0, 0, 0.92)
  tree_frame:SetBackdropBorderColor(0.6, 0.1, 0.1, 1)
  tree_frame:EnableMouse(true)
  local close = CreateFrame("Button", nil, tree_frame, "UIPanelButtonTemplate")
  close:SetSize(70, 20); close:SetPoint("TOPRIGHT", tree_frame, "TOPRIGHT", -8, -6); close:SetText("Close (K)")
  close:SetScript("OnClick", function() tree_frame:Hide() end)
  tree_frame.title = fstr(tree_frame)
  tree_frame.title:SetPoint("TOPLEFT", 14, -10)
  local gates = { [1] = 1, [6] = 2, [12] = 3, [18] = 4, [24] = 5, [30] = 6 }
  local col_of = { fire = 0, cold = 1, lightning = 2 }
  local seen = {}
  for _, sk in ipairs(Skills) do
    local key = sk.tree .. sk.req
    seen[key] = (seen[key] or 0) + 1
    local b = CreateFrame("Button", nil, tree_frame)
    b:SetSize(42, 42)
    b:SetPoint("TOPLEFT", tree_frame, "TOPLEFT", 20 + col_of[sk.tree] * 200 + (seen[key] - 1) * 50, -34 - (gates[sk.req] - 1) * 56)
    b.icon = tex(b); b.icon:SetAllPoints(b); b.icon:SetTexture(icon_path(sk.id))
    b.count = fstr(b, "GameFontHighlight"); b.count:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 2)
    b:SetScript("OnClick", function()
      local ok, why = Tree.allocate(world.player.st, sk.id)
      if not ok then say(sk.name .. ": " .. tostring(why)) else sync_bar(); save() end
      refresh_tree()
    end)
    b:SetScript("OnEnter", function(self) hover_id = sk.id; tooltip(self, sk.id) end)
    b:SetScript("OnLeave", function() hover_id = nil; GameTooltip:Hide() end)
    Game.tree_buttons[sk.id] = b
  end
  for _, sk in ipairs(Skills) do                     -- lines to prerequisites, where the client can draw lines
    for _, p in ipairs(sk.prereqs) do
      try(function()
        local l = tree_frame:CreateLine(nil, "BACKGROUND")
        l:SetThickness(2)
        l:SetColorTexture(COLORS[sk.element][1], COLORS[sk.element][2], COLORS[sk.element][3], 0.5)
        l:SetStartPoint("CENTER", Game.tree_buttons[p])
        l:SetEndPoint("CENTER", Game.tree_buttons[sk.id])
      end)
    end
  end
  tree_frame:Hide()
end

---------------------------------------------------------------- the orbs
local ORB, MASK = 84, "Interface\\CharacterFrame\\TempPortraitAlphaMask"

-- A round gauge in the Diablo style: gold rim, dark glass, a fill that rises from the bottom, a little shine, the numbers in the middle.
-- The circle comes from a mask texture; if the client refuses masks the orb is simply square, it still works.
local function build_orb(parent, x, r, g, b)
  local frame_ = CreateFrame("Frame", nil, parent)
  frame_:SetSize(ORB + 12, ORB + 12)
  frame_:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", x, 4)
  local function disc(layer, size, cr, cg, cb, alpha)
    local t = frame_:CreateTexture(nil, layer)
    t:SetSize(size, size); t:SetPoint("CENTER", frame_, "CENTER", 0, 0)
    t:SetColorTexture(cr, cg, cb, alpha or 1)
    try(function()
      local m = frame_:CreateMaskTexture()
      m:SetTexture(MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
      m:SetSize(size, size); m:SetPoint("CENTER", frame_, "CENTER", 0, 0)
      t:AddMaskTexture(m)
    end)
    return t
  end
  disc("BACKGROUND", ORB + 12, 0.62, 0.5, 0.2)          -- gold rim
  disc("BACKGROUND", ORB + 6, 0.05, 0.03, 0.03)        -- dark glass
  local fill = frame_:CreateTexture(nil, "ARTWORK")
  fill:SetColorTexture(r, g, b, 1)
  fill:SetPoint("BOTTOM", frame_, "BOTTOM", 0, 6); fill:SetSize(ORB, 1)
  try(function()
    local m = frame_:CreateMaskTexture()
    m:SetTexture(MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    m:SetSize(ORB, ORB); m:SetPoint("CENTER", frame_, "CENTER", 0, 0)
    fill:AddMaskTexture(m)
  end)
  local shine = disc("OVERLAY", ORB * 0.5, 1, 1, 1, 0.12)
  shine:ClearAllPoints(); shine:SetPoint("CENTER", frame_, "CENTER", -ORB * 0.16, ORB * 0.2)
  local text = frame_:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  text:SetPoint("CENTER", frame_, "CENTER", 0, 0)
  local orb_ = { frame = frame_, text = text, fill = fill, frac = 0 }
  function orb_.set(frac, label)
    frac = math.max(0, math.min(1, frac))
    orb_.frac = frac
    fill:SetHeight(math.max(1, ORB * frac))
    text:SetText(label)
  end
  return orb_
end

---------------------------------------------------------------- the main window
local function model_pool(parent, n, w, h)
  local pool = {}
  for i = 1, n do
    local m = CreateFrame("PlayerModel", nil, parent)
    m:SetSize(w, h)
    m:Hide()
    pool[i] = m
  end
  return pool
end

local function build()
  frame = CreateFrame("Frame", "DreadGameFrame", UIParent, "BackdropTemplate")
  frame:SetSize(VW + 20, VH + HUD_H + TITLE_H + 14)
  frame:SetPoint("CENTER")
  frame:SetClampedToScreen(true)
  frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
  frame:SetBackdropColor(0, 0, 0, 0.95)
  frame:SetBackdropBorderColor(0.6, 0.1, 0.1, 1)
  frame:SetMovable(true); frame:EnableMouse(true); frame:EnableKeyboard(true); frame:EnableMouseWheel(true)

  -- only the title bar drags the window, so right click is free for casting
  handle = CreateFrame("Frame", nil, frame)
  handle:SetSize(VW + 20, TITLE_H)
  handle:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
  handle:EnableMouse(true)
  handle:RegisterForDrag("LeftButton")
  handle:SetScript("OnDragStart", function() frame:StartMoving() end)
  handle:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)
  local title = fstr(handle, "GameFontNormalSmall")
  title:SetPoint("LEFT", handle, "LEFT", 10, 0)
  title:SetText("Dread " .. (ns.BUILD and ("(" .. ns.BUILD .. ")  ") or "") .. "drag here to move")
  zone_text = fstr(handle, "GameFontHighlightSmall")
  zone_text:SetPoint("CENTER", handle, "CENTER", -20, 0)
  local skills_btn = CreateFrame("Button", nil, handle, "UIPanelButtonTemplate")
  skills_btn:SetSize(86, 20); skills_btn:SetPoint("RIGHT", handle, "RIGHT", -100, 0); skills_btn:SetText("Skills (K)")
  skills_btn:SetScript("OnClick", function() Game.toggle_tree() end)
  -- reset asks twice, so a stray click cannot wipe a character
  reset_btn = CreateFrame("Button", nil, handle, "UIPanelButtonTemplate")
  reset_btn:SetSize(86, 20); reset_btn:SetPoint("RIGHT", handle, "RIGHT", -6, 0); reset_btn:SetText("New game")
  reset_btn:SetScript("OnClick", function() Game.press_reset() end)

  arena = CreateFrame("Frame", nil, frame)
  arena:SetSize(VW, VH)
  arena:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -TITLE_H - 2)
  arena:SetClipsChildren(true)
  ground = tex(arena, "BACKGROUND")
  ground:SetAllPoints(arena)
  ground:SetHorizTile(true); ground:SetVertTile(true)
  ground2 = arena:CreateTexture(nil, "BACKGROUND", nil, 1)         -- a big dirt layer over the grass, to hide the tiling
  ground2:SetAllPoints(arena)
  ground2:SetHorizTile(true); ground2:SetVertTile(true)

  doodad_f = model_pool(arena, MAX_DOODAD, 140, 170)
  mon_f = model_pool(arena, MAX_MON, 64, 80)
  for _, m in ipairs(mon_f) do
    m.fallback = tex(m, "ARTWORK"); m.fallback:SetAllPoints(m); m.fallback:SetColorTexture(0.7, 0.2, 0.2, 0.8); m.fallback:Hide()
    m.bar = tex(m, "OVERLAY"); m.bar:SetSize(40, 4); m.bar:SetPoint("BOTTOM", m, "TOP", 0, -2); m.bar:SetColorTexture(0.9, 0.1, 0.1, 1)
  end
  player_model = CreateFrame("PlayerModel", nil, arena)
  player_model:SetSize(70, 90)
  try(player_model.SetUnit, player_model, "player")

  for i = 1, MAX_PROJ do
    local f = CreateFrame("PlayerModel", nil, arena); f:SetSize(70, 70); f:Hide()
    f.icon = tex(f, "OVERLAY"); f.icon:SetSize(26, 26); f.icon:SetPoint("CENTER"); f.icon:SetBlendMode("ADD")
    proj_f[i] = f
  end
  for i = 1, MAX_BLAST do
    local f = CreateFrame("PlayerModel", nil, arena); f:SetSize(150, 150); f:Hide()
    f.icon = tex(f, "OVERLAY"); f.icon:SetPoint("CENTER"); f.icon:SetBlendMode("ADD")
    f.life, f.max = 0, 0.6
    blast_f[i] = f
  end
  for i = 1, MAX_DROP do
    local t = tex(arena, "OVERLAY"); t:SetSize(22, 22); t:SetTexture(icon_path("wand")); t:Hide()
    t:SetTexture("Interface\\Icons\\INV_Potion_54"); t:SetDesaturated(true); drop_f[i] = t
  end
  for i = 1, MAX_FLOAT do
    local fs = fstr(arena, "GameFontHighlight"); fs:Hide(); float_f[i] = { fs = fs, t = 0 }
  end
  exit_marks = {}
  for i = 1, 2 do
    local t = tex(arena, "ARTWORK"); t:SetSize(56, 56); t:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    t:SetDesaturated(true); t:SetVertexColor(0.7, 0.4, 1); t:SetBlendMode("ADD"); t:Hide()
    local l = fstr(arena, "GameFontNormalSmall"); l:Hide()
    exit_marks[i] = { t = t, l = l }
  end
  for i = 1, 48 do                                              -- the /dread solid circles
    local t = arena:CreateTexture(nil, "OVERLAY", nil, 3)
    t:SetColorTexture(1, 0.1, 0.1, 0.4); t:Hide()
    try(function()
      local m = arena:CreateMaskTexture()
      m:SetTexture(MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
      m:SetAllPoints(t)
      t:AddMaskTexture(m)
    end)
    solid_f[i] = t
  end
  over_text = fstr(arena, "GameFontNormalLarge")
  over_text:SetPoint("CENTER", arena, "CENTER", 0, 0); over_text:Hide()
  toast_text = fstr(arena, "GameFontNormalLarge")
  toast_text:SetPoint("TOP", arena, "TOP", 0, -30)

  hud = CreateFrame("Frame", nil, frame)
  hud:SetSize(VW, HUD_H)
  hud:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 10, 6)
  life_orb = build_orb(hud, 0, 0.78, 0.08, 0.08)
  mana_orb = build_orb(hud, VW - (ORB + 12), 0.12, 0.28, 0.9)
  local mid = ORB + 12 + (VW - 2 * (ORB + 12) - SLOTS * 42) / 2      -- the skill bar sits centred between the orbs
  for i = 1, SLOTS do
    local b = CreateFrame("Button", nil, hud)
    b:SetSize(40, 40)
    b:SetPoint("TOPLEFT", hud, "TOPLEFT", mid + (i - 1) * 42, -6)
    b.bg = tex(b, "BACKGROUND"); b.bg:SetAllPoints(b); b.bg:SetColorTexture(0.12, 0.1, 0.08, 0.95)
    b.icon = tex(b); b.icon:SetAllPoints(b)
    b.key = fstr(b, "GameFontHighlightSmall"); b.key:SetPoint("TOPLEFT", 2, -2); b.key:SetText(tostring(i))
    b.sel = tex(b, "OVERLAY"); b.sel:SetAllPoints(b); b.sel:SetColorTexture(1, 0.85, 0.3, 0.35); b.sel:Hide()
    b:SetScript("OnClick", function() if bar[i] then sel = i end end)
    slots[i] = b
  end
  xp_bar = tex(hud); xp_bar:SetPoint("TOPLEFT", hud, "TOPLEFT", mid, -52); xp_bar:SetSize(SLOTS * 42 - 2, 5); xp_bar:SetColorTexture(0.9, 0.8, 0.2, 1)
  info_text = fstr(hud, "GameFontHighlightSmall"); info_text:SetPoint("TOPLEFT", hud, "TOPLEFT", mid, -62)
  hint_text = fstr(hud, "GameFontNormalSmall"); hint_text:SetPoint("TOPLEFT", hud, "TOPLEFT", mid - 20, -76)
  hint_text:SetWidth(SLOTS * 42 + 40)
  hint_text:SetJustifyH("LEFT")

  frame:SetScript("OnMouseDown", function(_, button)
    if world.over then new_world(); return end
    local x, y = world_xy()
    if x < cam.x or y < cam.y or x > cam.x + VW or y > cam.y + VH then return end
    if button == "RightButton" then
      local id = bar[sel]
      if not id then hint_text:SetText("No skill on that slot. Open the tree (K), spend a point, hover the skill and press 1-8."); return end
      local ok, why = Combat.cast(world, id, x, y)
      if not ok then hint_text:SetText(Skills.byId[id].name .. ": " .. tostring(why)) end
    elseif button == "LeftButton" then
      if IsShiftKeyDown and IsShiftKeyDown() and bar[sel] then
        Combat.cast(world, bar[sel], x, y)
        return
      end
      target = nil
      for _, m in ipairs(world.monsters) do
        if not m.dead and math.sqrt((m.x - x) ^ 2 + (m.y - y) ^ 2) <= m.radius + 24 then target = m; break end
      end
      if not target then Combat.move_to(world, x, y) end
    end
  end)
  frame:SetScript("OnMouseWheel", function(_, delta) rotate(delta > 0 and -1 or 1) end)
  frame:SetScript("OnKeyDown", function(self, key)
    local handled = false
    local n = tonumber(key)
    if n and n >= 1 and n <= SLOTS then
      if tree_frame:IsShown() and hover_id and castable(hover_id) and Tree.points_in(world.player.st, hover_id) > 0 then
        for i = 1, SLOTS do if bar[i] == hover_id then bar[i] = nil end end
        bar[n], sel = hover_id, n
        hint_text:SetText(Skills.byId[hover_id].name .. " is now on slot " .. n)
        save()
      elseif bar[n] then sel = n
      end
      handled = true
    elseif key == "TAB" then rotate(1); handled = true
    elseif key == "K" then Game.toggle_tree(); handled = true
    end
    self:SetPropagateKeyboardInput(not handled)
  end)
  frame:SetScript("OnUpdate", function(_, dt) Game.tick(dt) end)
  build_tree()
  frame:Hide()
end

---------------------------------------------------------------- one frame of the game
local function vis(sx, sy, mx, my) return sx > -mx and sx < VW + mx and sy > -my and sy < VH + my end

local function draw_scenery()
  -- keep a scenery piece on the frame it already has; hand free frames to pieces that have just come into view
  local seen = {}
  for _, d in ipairs(area.doodads) do
    if vis(d.x - cam.x, d.y - cam.y, 80, 100) then
      seen[d] = true
      if not doodad_slot[d] then
        for _, f in ipairs(doodad_f) do
          if not f.owner then
            f.owner, doodad_slot[d] = d, f
            local spec = Zone.SCENERY[d.kind]
            f:SetSize(d.w * spec.frame, d.h * spec.frame)           -- bigger than the model, or it is cut off at the frame edge
            try(f.SetModel, f, d.id)
            try(f.SetCamDistanceScale, f, Game.cam_for(d.kind))
            f.fallback_missing = false
            f:Show()
            break
          end
        end
      end
    end
  end
  for d, f in pairs(doodad_slot) do
    if not seen[d] then f.owner, doodad_slot[d] = nil, nil; f:Hide() end
  end
  for d, f in pairs(doodad_slot) do
    place(f, d.x, d.y, d.h); depth(f, d.y)
  end
end

function Game.tick(dt)
  if dt > 0.1 then dt = 0.1 end
  Game.paused = tree_frame:IsShown()
  local p = world.player
  -- walk up to a clicked monster and keep using the wand on it
  if target and not world.over and not Game.paused then
    if target.dead then target = nil
    else
      local d = math.sqrt((target.x - p.x) ^ 2 + (target.y - p.y) ^ 2)
      if d > ATTACK_RANGE then Combat.move_to(world, target.x, target.y)
      else p.tx, p.ty = nil, nil; Combat.attack(world, target.x, target.y) end
    end
  end
  if not world.over and not Game.paused then Combat.step(world, dt) end
  sync_bar()

  -- leave through an exit?
  if not Game.paused and not world.over then
    for _, ex in ipairs(area.exits) do
      if math.sqrt((p.x - ex.x) ^ 2 + (p.y - ex.y) ^ 2) <= ex.r then
        local dest = Zone.get(ex.to)
        enter(ex.to, ex.arrive or dest.spawn)
        break
      end
    end
  end

  -- the camera follows you
  cam.x = math.max(0, math.min(area.w - VW, p.x - VW / 2))
  cam.y = math.max(0, math.min(area.h - VH, p.y - VH / 2))
  local fl = area.floor
  local T = (DreadDB and DreadDB.tile) or fl.tile
  ground:SetTexCoord(cam.x / T, (cam.x + VW) / T, -(cam.y + VH) / T, -cam.y / T)
  local T2 = fl.overlay_tile
  ground2:SetTexCoord(cam.x / T2, (cam.x + VW) / T2, -(cam.y + VH) / T2, -cam.y / T2)
  draw_scenery()
  do                                                              -- the blocking circles, when asked for
    local n = 0
    solid_sizes = {}
    if solid_on then
      for _, o in ipairs(world.obstacles) do
        local sx, sy = o.x - cam.x, o.y - cam.y
        if n < #solid_f and vis(sx, sy, 40, 40) then
          n = n + 1
          local t = solid_f[n]
          t:SetSize(o.r * 2, o.r * 2); t:ClearAllPoints(); t:SetPoint("CENTER", arena, "BOTTOMLEFT", sx, sy); t:Show()
          solid_sizes[#solid_sizes + 1] = o.r * 2
        end
      end
    end
    for i = n + 1, #solid_f do solid_f[i]:Hide() end
  end

  -- you
  place(player_model, p.x, p.y, 90); depth(player_model, p.y)
  local casting = (world.time - p.cast_at) < 0.5
  if world.over then set_anim(player_model, Game.ANIM.DEATH)
  elseif casting then set_anim(player_model, Game.ANIM.CAST)
  elseif p.tx then set_anim(player_model, Game.ANIM.RUN)
  else set_anim(player_model, Game.ANIM.STAND) end
  if p.tx then face(player_model, p.tx - p.x, p.ty - p.y)
  elseif target and not target.dead then face(player_model, target.x - p.x, target.y - p.y) end

  -- monsters: the nearest ones that are on screen
  local shown, n = {}, 0
  for _, m in ipairs(world.monsters) do
    local gone = m.dead and (world.time - (m.died_at or 0) > 3)
    if not gone and vis(m.x - cam.x, m.y - cam.y, 60, 80) then shown[#shown + 1] = m end
  end
  for i = 1, MAX_MON do
    local m, f = shown[i], mon_f[i]
    if m then
      if f.owner ~= m then
        f.owner, f.anim = m, nil
        local ok = try(f.SetCreature, f, m.cid)
        f.fallback:SetShown(not ok)
        if m.scale then try(f.SetModelScale, f, m.scale) else try(f.SetModelScale, f, 1) end
      end
      local size = (m.scale or 1)
      f:SetSize(64 * size, 80 * size)
      place(f, m.x, m.y, 80 * size); depth(f, m.y)
      f:SetAlpha(m.dead and 0.5 or ((m.freeze > 0) and 0.6 or 1))
      f.bar:SetWidth(math.max(1, 40 * math.max(0, m.life) / m.maxlife))
      f.bar:SetShown(not m.dead)
      if m.dead then set_anim(f, Game.ANIM.DEATH)
      elseif m.bite_at and world.time - m.bite_at < 0.45 then set_anim(f, Game.ANIM.ATTACK)
      elseif m.moving then set_anim(f, Game.ANIM.WALK)
      else set_anim(f, Game.ANIM.STAND) end
      if not m.dead and m.awake then face(f, p.x - m.x, p.y - m.y) end
      f:Show()
    else
      f.owner = nil; f:Hide()
    end
  end

  -- spell effects
  for i = 1, MAX_PROJ do
    local pr, f = world.projectiles[i], proj_f[i]
    if pr then
      local el = element_of(pr.id)
      local c = COLORS[el]
      if f.pid ~= pr.id then
        f.pid = pr.id
        f.icon:SetTexture(icon_path(pr.id)); f.icon:SetVertexColor(c[1], c[2], c[3])
        local mid = PROJ_MODEL[pr.id]
        if mid then try(f.SetModel, f, mid); try(f.SetModelScale, f, PROJ_SCALE[pr.id] or 1) end
      end
      f:ClearAllPoints(); f:SetPoint("CENTER", arena, "BOTTOMLEFT", pr.x - cam.x, pr.y - cam.y)
      face(f, pr.vx, pr.vy)
      f:SetFrameLevel(arena:GetFrameLevel() + 300)
      f:Show()
    else
      f.pid = nil; f:Hide()
    end
  end
  for _, e in ipairs(Combat.drain(world)) do
    if e.k == "hit" and e.dmg > 0 then
      for _, fl in ipairs(float_f) do
        if fl.t <= 0 then
          fl.t, fl.x, fl.y = 0.8, e.x, e.y + 40
          fl.fs:SetText(tostring(math.floor(e.dmg + 0.5)))
          local c = COLORS[element_of(e.id)]; fl.fs:SetTextColor(c[1], c[2], c[3])
          break
        end
      end
    elseif e.k == "blast" then
      for _, f in ipairs(blast_f) do
        if f.life <= 0 then
          local el = element_of(e.id)
          f.life, f.x, f.y, f.r = f.max, e.x, e.y, e.r
          f.icon:SetTexture(icon_path(e.id)); f.icon:SetVertexColor(COLORS[el][1], COLORS[el][2], COLORS[el][3])
          if BLAST_MODEL[el] then try(f.SetModel, f, BLAST_MODEL[el]) end
          break
        end
      end
    elseif e.k == "level" then
      toast_text:SetText("Level " .. e.level .. "!  Press K to spend a skill point."); toast_t = 4
      save()
    elseif e.k == "kill" or e.k == "pickup" then
      save()
    elseif e.k == "boss_dead" then
      if not world.flags.den then
        world.flags.den = true
        world.player.st.quest_points = world.player.st.quest_points + 1
        toast_text:SetText("Quest complete!  +1 skill point.  Press K."); toast_t = 6
        save()
      end
    end
  end
  for _, fl in ipairs(float_f) do
    if fl.t > 0 then
      fl.t = fl.t - dt; fl.y = fl.y + 40 * dt
      fl.fs:ClearAllPoints(); fl.fs:SetPoint("CENTER", arena, "BOTTOMLEFT", fl.x - cam.x, fl.y - cam.y)
      fl.fs:SetAlpha(math.min(1, fl.t / 0.4)); fl.fs:Show()
      if fl.t <= 0 then fl.fs:Hide() end
    end
  end
  for _, f in ipairs(blast_f) do
    if f.life > 0 then
      f.life = f.life - dt
      local k = 1 - f.life / f.max
      f.icon:SetSize(f.r * 2 * (0.4 + 0.6 * k), f.r * 2 * (0.4 + 0.6 * k)); f.icon:SetAlpha(1 - k)
      f:ClearAllPoints(); f:SetPoint("CENTER", arena, "BOTTOMLEFT", f.x - cam.x, f.y - cam.y)
      f:SetFrameLevel(arena:GetFrameLevel() + 290)
      f:Show()
      if f.life <= 0 then f:Hide() end
    end
  end
  for i = 1, MAX_DROP do
    local d, t = world.drops[i], drop_f[i]
    if d then
      t:SetVertexColor(d.kind == "mana" and 0.3 or 1, d.kind == "mana" and 0.5 or 0.2, d.kind == "mana" and 1 or 0.2)
      t:ClearAllPoints(); t:SetPoint("CENTER", arena, "BOTTOMLEFT", d.x - cam.x, d.y - cam.y); t:Show()
    else
      t:Hide()
    end
  end
  for i, ex in ipairs(area.exits) do
    local mk = exit_marks[i]
    mk.t:ClearAllPoints(); mk.t:SetPoint("CENTER", arena, "BOTTOMLEFT", ex.x - cam.x, ex.y - cam.y)
    mk.l:ClearAllPoints(); mk.l:SetPoint("BOTTOM", mk.t, "TOP", 0, 2); mk.l:SetText(ex.label)
    local on = vis(ex.x - cam.x, ex.y - cam.y, 40, 40)
    mk.t:SetShown(on); mk.l:SetShown(on)
  end

  -- HUD
  life_orb.set(p.life / p.maxlife, math.floor(p.life) .. "/" .. p.maxlife)
  mana_orb.set(p.mana / p.maxmana, math.floor(p.mana) .. "/" .. p.maxmana)
  xp_bar:SetWidth(math.max(1, (SLOTS * 42 - 2) * p.xp / Combat.xp_for_next(p.level)))
  info_text:SetText(string.format("Level %d    Skill points %d    %d FPS", p.level, Tree.points_free(p.st), math.floor(GetFramerate())))
  zone_text:SetText(area.title .. (area.quest and (world.flags.den and "   Quest done" or ("   " .. area.quest.title)) or ""))
  for i = 1, SLOTS do
    local b, id = slots[i], bar[i]
    if id then b.icon:SetTexture(icon_path(id)); b.icon:SetAlpha(1) else b.icon:SetTexture(nil) end
    b.sel:SetShown(i == sel and id ~= nil)
  end
  if toast_t > 0 then
    toast_t = toast_t - dt
    toast_text:SetAlpha(math.min(1, toast_t)); toast_text:Show()
    if toast_t <= 0 then toast_text:Hide() end
  end
  if Game.paused then hint_text:SetText("Paused while the skill tree is open. Hover a skill and press 1-8 to put it on your bar. K closes it.")
  elseif Tree.points_spent(p.st) == 0 then hint_text:SetText("Left click: walk, or attack a monster with your wand (free). Press K to spend your first skill point. Tab or wheel rotates skills.")
  end
  if world.over then
    over_text:SetText("You died.  Click to start again.\n(your level, skills and quest progress are kept)"); over_text:Show()
  else
    over_text:Hide()
  end
  if tree_frame:IsShown() then refresh_tree() end
end

---------------------------------------------------------------- opening, closing, settings
Game.DEFAULT_SCALE = 1.6
function Game.set_scale(x)
  x = tonumber(x) or Game.DEFAULT_SCALE
  if x < 0.8 then x = 0.8 elseif x > 3 then x = 3 end
  DreadDB = DreadDB or {}
  DreadDB.scale = x
  if frame then frame:SetScale(x) end
  if tree_frame then tree_frame:SetScale(x) end
  return x
end

-- Which way the models face is not known until seen; this nudges it (radians), saved.
function Game.set_facing(r)
  DreadDB = DreadDB or {}
  DreadDB.facing = tonumber(r) or 0
  return DreadDB.facing
end

-- Live tuning, saved: how big the ground texture tiles (units), and how far the camera sits from each kind of scenery.
function Game.set_tile(n)
  DreadDB = DreadDB or {}
  n = tonumber(n)
  DreadDB.tile = (n and n >= 32 and n <= 2048) and n or nil
  return DreadDB.tile or "default"
end

function Game.cam_for(kind)
  return (DreadDB and DreadDB.cam and DreadDB.cam[kind]) or Zone.SCENERY[kind].cam
end

function Game.set_cam(kind, n)
  if not Zone.SCENERY[kind] then return nil, "unknown kind (tree, fallen, bush, grave, rock)" end
  n = tonumber(n)
  if not n or n < 0.3 or n > 10 then return nil, "pick a number between 0.3 and 10" end
  DreadDB = DreadDB or {}
  DreadDB.cam = DreadDB.cam or {}
  DreadDB.cam[kind] = n
  for d, f in pairs(doodad_slot) do
    if d.kind == kind then try(f.SetCamDistanceScale, f, n) end
  end
  return n
end

-- Start the character over: forget the save, and if the game is already built, replace the live world too
-- (otherwise closing the window would simply save the old character back).
function Game.reset()
  DreadDB = DreadDB or {}
  DreadDB.char, DreadDB.bar = nil, nil
  if frame then
    new_world()
    if Tree.points_spent(world.player.st) == 0 and tree_frame then refresh_tree(); tree_frame:Show() end
  end
end

-- The in-game button: the first click arms it, a second click within three seconds does it.
function Game.press_reset()
  if reset_armed then
    reset_armed = false
    reset_btn:SetText("New game")
    Game.reset()
    hint_text:SetText("New character: level 1, no skills.")
    return
  end
  reset_armed = true
  reset_btn:SetText("Sure? Click")
  C_Timer.After(3, function()
    if reset_armed then reset_armed = false; reset_btn:SetText("New game") end
  end)
end

function Game.toggle_tree()
  if tree_frame:IsShown() then tree_frame:Hide() else refresh_tree(); tree_frame:Show() end
end

function Game.toggle()
  if not frame then
    build()
    Game.set_scale(DreadDB and DreadDB.scale or Game.DEFAULT_SCALE)
    new_world()
  end
  if frame:IsShown() then
    save(); frame:Hide(); tree_frame:Hide()
  else
    if world.over then new_world() end
    frame:Show()
    if Tree.points_spent(world.player.st) == 0 then refresh_tree(); tree_frame:Show() end
  end
end

-- /dread animtest: plays animation ids on your own model one at a time so the right ones can be picked by eye.
function Game.animtest()
  local ids = { 0, 1, 2, 4, 5, 6, 16, 17, 26, 32, 33, 34, 51, 52, 53, 54 }
  local f = CreateFrame("PlayerModel", nil, UIParent)
  f:SetSize(200, 260); f:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
  try(f.SetUnit, f, "player")
  f:Show()
  for i, id in ipairs(ids) do
    C_Timer.After(i * 2.5, function()
      try(f.SetAnimation, f, id)
      say(string.format("[%d/%d] animation %d", i, #ids, id))
      if i == #ids then C_Timer.After(2.5, function() f:Hide(); say("done. Tell me which number looked like casting a spell, and which like an attack.") end) end
    end)
  end
end

function Game.solid() return solid_on end
function Game.solid_sizes() return solid_sizes end
function Game.set_solid(on) solid_on = on and true or false; return solid_on end
function Game.orbs() return life_orb, mana_orb end
function Game.world() return world end
function Game.camera() return cam end
function Game.area() return area end
function Game.bar() return bar, sel end

return Game
