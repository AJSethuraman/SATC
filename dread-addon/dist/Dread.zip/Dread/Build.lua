-- Written by build_installer.py. Do not edit.
local _, ns = ...
ns = ns or {}
ns.BUILD = "11 Nov 20:41 UTC"
