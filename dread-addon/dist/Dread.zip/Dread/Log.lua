-- Dread's own message window, so nothing has to go to the General chat tab.
--   /dread log          show or hide it (closing it with the X keeps it closed until you ask for it again)
--   /dread log clear    empty it
--   /dread log copy     a box with the whole log as plain text: Ctrl+A, Ctrl+C, paste anywhere
--   /dread log chat     also copy every message to the General chat tab (off by default)
-- Messages are kept (the last 500) even while the window is hidden, and replay into it when it opens.
local ADDON, ns = ...
local Log = {}
ns.Log = Log

local MAX = 500
local lines, frame, msgframe, box = {}, nil, nil, nil

local function cfg()
  DreadDB = DreadDB or {}
  DreadDB.log = DreadDB.log or {}
  return DreadDB.log
end

local function stamp()
  local ok, t = pcall(date, "%H:%M:%S")
  return (ok and t) and ("|cff888888" .. t .. "|r ") or ""
end

function Log.lines() return lines end

-- The whole log with colour codes stripped, for copying out.
function Log.plain()
  local out = {}
  for i, l in ipairs(lines) do
    out[i] = l:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  end
  return table.concat(out, "\n")
end

-- WoW draws no text, and raises "Font not set" from AddMessage / SetText, until a widget has a font. Try the chat font,
-- then a font file every client has, then the game's own text font. Returns whether any of them worked.
local function set_font(widget)
  if ChatFontNormal and pcall(widget.SetFontObject, widget, ChatFontNormal) then return true end
  if pcall(widget.SetFont, widget, "Fonts\\FRIZQT__.TTF", 13, "") then return true end
  if GameFontNormal and pcall(widget.SetFontObject, widget, GameFontNormal) then return true end
  return false
end

local function save_place()
  local c = cfg()
  local ok, p, _, rp, x, y = pcall(frame.GetPoint, frame, 1)
  if ok and p then c.point = { p, rp or p, x or 0, y or 0 } end
  local w, h = frame:GetWidth(), frame:GetHeight()
  if type(w) == "number" and type(h) == "number" then c.w, c.h = w, h end
end

local function build()
  if frame then return end
  local c = cfg()
  frame = CreateFrame("Frame", "DreadLogFrame", UIParent, "BackdropTemplate")
  frame:SetSize(c.w or 440, c.h or 230)
  local pt = c.point
  if type(pt) == "table" then frame:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4]) else frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -80) end
  frame:SetClampedToScreen(true)
  frame:SetFrameStrata("MEDIUM")
  frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
  frame:SetBackdropColor(0, 0, 0, 0.8)
  frame:SetBackdropBorderColor(0.6, 0.1, 0.1, 1)
  frame:SetMovable(true); frame:SetResizable(true); frame:EnableMouse(true)
  pcall(frame.SetResizeBounds, frame, 260, 110)
  pcall(frame.SetMinResize, frame, 260, 110)

  local bar = CreateFrame("Frame", nil, frame)
  bar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
  bar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
  bar:SetHeight(20)
  bar:EnableMouse(true)
  bar:RegisterForDrag("LeftButton")
  bar:SetScript("OnDragStart", function() frame:StartMoving() end)
  bar:SetScript("OnDragStop", function() frame:StopMovingOrSizing(); save_place() end)
  local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  title:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -5)
  title:SetText("Dread log")
  local function button(text, w, anchor_x, fn)
    local b = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    b:SetSize(w, 16); b:SetPoint("TOPRIGHT", bar, "TOPRIGHT", anchor_x, -2); b:SetText(text)
    b:SetScript("OnClick", fn)
    return b
  end
  button("X", 20, -3, function() cfg().hidden = true; frame:Hide() end)
  button("Clear", 44, -26, function() Log.clear() end)
  button("Copy", 44, -73, function() Log.copy() end)

  msgframe = CreateFrame("ScrollingMessageFrame", nil, frame)
  msgframe:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -24)
  msgframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 8)
  set_font(msgframe)
  msgframe:SetMaxLines(MAX)
  msgframe:SetFading(false)
  msgframe:SetJustifyH("LEFT")
  pcall(msgframe.SetInsertMode, msgframe, "BOTTOM")
  msgframe:EnableMouseWheel(true)
  msgframe:SetScript("OnMouseWheel", function(self, delta)
    if delta > 0 then self:ScrollUp() else self:ScrollDown() end
  end)
  local grip = CreateFrame("Button", nil, frame)
  grip:SetSize(16, 16); grip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
  local gt = grip:CreateTexture(nil, "OVERLAY"); gt:SetAllPoints(grip); gt:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
  grip:SetScript("OnMouseUp", function() frame:StopMovingOrSizing(); save_place() end)
  for _, l in ipairs(lines) do msgframe:AddMessage(l) end           -- what arrived before the window existed
end

function Log.chat_on() return DreadDB ~= nil and DreadDB.chat == true end

-- The one door every Dread message goes through.
function ns.log(msg)
  msg = tostring(msg)
  local ok = CreateFrame and pcall(build)           -- build first: it replays what is already in `lines`, and this line is not in it yet
  local line = stamp() .. msg
  lines[#lines + 1] = line
  if #lines > MAX then table.remove(lines, 1) end
  if Log.chat_on() then print(msg) end
  local shown = false
  if ok and frame then
    shown = pcall(msgframe.AddMessage, msgframe, line)
    if shown and not cfg().hidden and not frame:IsShown() then frame:Show() end
  end
  if not shown and not Log.chat_on() then print(msg) end       -- if the window cannot show it, the chat tab does: never lose a message
end

function Log.toggle()
  pcall(build)
  if not frame then return false end
  if frame:IsShown() then
    cfg().hidden = true; frame:Hide()
  else
    cfg().hidden = nil; frame:Show()
  end
  return frame:IsShown()
end

-- Open the log next to another window (the game): to its right, or its left if there is no room. A position you chose by
-- dragging the log wins; this only places it when it has none saved.
function Log.open_beside(anchor)
  pcall(build)
  if not frame then return false end
  cfg().hidden = nil
  if type(cfg().point) ~= "table" and anchor then
    local ok, right = pcall(anchor.GetRight, anchor)
    local sw = UIParent and UIParent.GetWidth and UIParent:GetWidth() or nil
    local w = frame:GetWidth() or 440
    frame:ClearAllPoints()
    if ok and type(right) == "number" and type(sw) == "number" and type(anchor.GetScale) == "function" and right * (anchor:GetScale() or 1) + w + 16 > sw then
      frame:SetPoint("TOPRIGHT", anchor, "TOPLEFT", -8, 0)
    else
      frame:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 8, 0)
    end
  end
  frame:Show()
  return true
end

-- Close it for now. Marked hidden so the next message does not pop it straight back open; Log.toggle or Log.open_beside reopens.
function Log.close()
  if frame then cfg().hidden = true; frame:Hide() end
end

function Log.clear()
  lines = {}
  if msgframe then msgframe:Clear() end
end

-- Put some text in a box to select and copy: the whole log by default, or `text`.
function Log.copy(text)
  if not box then
    box = CreateFrame("Frame", "DreadLogCopy", UIParent, "BackdropTemplate")
    box:SetSize(520, 300); box:SetPoint("CENTER"); box:SetFrameStrata("DIALOG")
    box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    box:SetBackdropColor(0, 0, 0, 0.95); box:SetBackdropBorderColor(0.6, 0.1, 0.1, 1)
    local hint = box:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hint:SetPoint("TOPLEFT", 10, -8); hint:SetText("Ctrl+A, then Ctrl+C, then paste. Esc closes.")
    box.edit = CreateFrame("EditBox", nil, box)
    box.edit:SetMultiLine(true); box.edit:SetPoint("TOPLEFT", 10, -26); box.edit:SetSize(500, 262)
    set_font(box.edit)
    box.edit:SetAutoFocus(true)
    box.edit:SetScript("OnEscapePressed", function() box:Hide() end)
  end
  box.edit:SetText(text or Log.plain())
  box:Show()
  box.edit:SetFocus(); box.edit:HighlightText()
end

function Log.set_chat(on)
  DreadDB = DreadDB or {}
  DreadDB.chat = on and true or nil
  return DreadDB.chat == true
end

return Log
