-- Written by build_installer.py. Do not edit.
local _, ns = ...
ns = ns or {}
ns.BUILD = "21 Nov 23:21 UTC"
